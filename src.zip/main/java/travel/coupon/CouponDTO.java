package travel.coupon;

public class CouponDTO {

}
