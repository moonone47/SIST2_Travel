package travel.login;

public class LoginDTO {

}
