package travel.mypage;

public class MypageDTO {

}
