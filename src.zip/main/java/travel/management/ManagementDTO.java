package travel.management;

public class ManagementDTO {

}
