package travel.management;

public class ManagementDAO {

}
