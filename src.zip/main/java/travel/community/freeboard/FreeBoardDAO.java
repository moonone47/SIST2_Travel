package travel.community.freeboard;

public class FreeBoardDAO {

}
