package travel.community.travelreview;

public class CommentDAO {

}
