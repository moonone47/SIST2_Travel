package travel.community.clubboard;
public class ClubBoardCommentDTO {

}
