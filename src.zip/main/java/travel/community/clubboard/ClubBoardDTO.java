package travel.community.clubboard;
public class ClubBoardDTO {

}
